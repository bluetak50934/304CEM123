const express = require('express');
const router = express.Router();

let dbo;
let connectionString = 'mongodb://localhost:27017';

const mongodb = require('mongodb');

mongodb.connect(
  connectionString,
  { useNewUrlParser: true, useUnifiedTopology: true },
  function (err, client) {
   if (err) throw err;
   dbo = client.db("users");
   console.log("Native driver mongodb CONNECTED!");
  }
);


router.post('/reg_user', async(req, res) => {
   try {
      // throw "ERROR";
      var user = req.body.login;
      var pwd = req.body.password;
      var name = req.body.name;
      var email = req.body.email;
      var gender = req.body.gender;
      var items = [];

      var query = {"login": user,"pwd": pwd,"name": name,"email": email,"gender": gender,"cart":items};
      var findQuery = { $or: [{"login": user},{"email":email}] };

      //console.log(query);
      if (user === undefined || pwd === undefined) {
         throw "ERROR";
      } else {
         let resultDBregcheck = await dbo.collection("userdbs").find(findQuery).toArray();
         // console.log(resultDBregcheck);
         // console.log(resultDBregcheck.length);
         if (resultDBregcheck.length > 0) {
            res.json({ message: 'Record Found! Choose another login info.', status: "1"});
         } else {
            let resultDBreg = await dbo.collection("userdbs").insertOne(query);
            // console.log(resultDBreg);
            // console.log("2nd"+resultDBreg.length);
            if (resultDBreg.length > 0) {
               res.json({ message: 'Insert Error! Choose another login info!', status: "1"});
            } else {
               console.log("Inserted Data: "+JSON.stringify(resultDBreg.ops[0]));
               console.log("Inserted Count: "+resultDBreg.insertedCount);
               res.json({ message: 'Register OK!', status: "0"});
            }

         }
        
      }
      
   } catch (e) {
      res.json(e);
   }
});

router.post('/check_user', async(req, res) => {
   try {
      // throw "ERROR";
      var user = req.body.login;
      var pwd = req.body.password;
      
      var query = {"login": user, "pwd": pwd};
      // console.log(query);
      if (user === undefined || pwd === undefined) {
         throw "ERROR";
      } else {
         let resultDB = await dbo.collection("userdbs").find(query).toArray();
         console.log(resultDB);
         res.json(resultDB);
      }

   } catch (e) {
      res.json(e);
   }
});

module.exports = router;