const Product = require('../model/product');

exports.getAllProducts = (req, res, next) => {
    Product.find()
        .then(products => {
            console.log("Showing all products!");
            res.render('shop', { name: 'CycleWorld', prods: products, path: '/shop', pageTitle: 'Shop' });
        })
        .catch(err => console.log(err));
};

exports.getProductDetail = (req, res, next) => {
    Product.findById(req.params.prodId)
        .then(product => {
            console.log("Product Displaying!");
            res.render('product-detail', { prod: product, pageTitle: 'Product Detail', path: '/shop', name: 'CycleWorld' });
        })
        .catch(err => console.log(err));
}

exports.addToCart = (req, res, next) => {
    console.log("exports addToCart req.body.id "+req.body.id);
    console.log("exports addToCart req.user "+req.user);
    console.log("exports addToCart applocalsid "+req.app.locals.id);
    req.user.addToCart(req.body.id)
        .then(() => {
            console.log("Added to Cart!");
            res.redirect('/cart');
        }).catch(err => console.log(err));
}

exports.getCart = (req, res, next) => {
    req.user
        .populate('cart.items.productId')
        .execPopulate()
        .then(user => {
            console.log("Showing cart items!");
            res.render('cart', { cart: user.cart, pageTitle: 'Shopping Cart Detail', path: '/cart', name: 'CycleWorld' });
        })
        .catch(err => console.log(err));
}

exports.deleteInCart = (req, res, next) => {
    req.user.removeFromCart(req.body.prodId)
        .then(() => {
            console.log("Item removed from cart!");
            res.redirect('/cart');
        }).catch(err => console.log(err));

}