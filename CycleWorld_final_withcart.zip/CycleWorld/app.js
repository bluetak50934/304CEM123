console.log("EXPRESS APP RUN!");

const express = require('express');
const dotenv = require('dotenv');
const morgan = require('morgan');
const bodyparser = require("body-parser");
const cookieParser = require("cookie-parser");
const users = require('./routes/users');
const path = require('path');
const connectDB = require('./admin/server/database/connection');
const mongoose = require('mongoose');

//cart
const adminMainRoutes = require('./admin/server/routes/admin');
const shopRoutes = require('./admin/server/routes/shop');
const userRoutes = require('./admin/server/routes/user');
const User = require('./admin/server/model/user');


const app = express();

dotenv.config( { path : 'config.env'} )
const PORT = process.env.PORT || 8080


//log requests (Minimal mode)
// app.use(morgan('tiny'));

//Mongo
var dbo;
let connectionString = 'mongodb://localhost:27017';
// mongodb connection
connectDB();

//Load all required template files
app.use(express.json());
app.use(express.urlencoded({extended: true}));
app.use('/assets', express.static('assets'));
app.use(express.static(path.join(__dirname, 'public')));
// app.use(express.static('public'));
app.use('/stylesheets/fontawesome', express.static(__dirname + '/node_modules/@fortawesome/fontawesome-free/'));

// parse request to body-parser
app.use(bodyparser.urlencoded({ extended : true}))
// set view engine
app.set("view engine", "ejs")
// load routers
app.use('/admin', require('./admin/server/routes/router'))
// load assets
app.use('/files/css', express.static(__dirname + "/admin/files/css"))
app.use('/files/img', express.static(__dirname + "/admin/files/img"))
app.use('/files/js', express.static(__dirname + "/admin/files/js"))

//Process request URLs
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});
app.get('/index', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});
app.use('/login', (req, res) => {
    res.sendFile(__dirname + '/login.html');
});
app.get('/registration', (req, res) => {
    res.sendFile(__dirname + '/registration.html');
});
app.get('/shopbikes', (req, res) => {
    res.sendFile(__dirname + '/shopbikes.html');
});

//cart
// app.use((req, res, next) => {
//     app.locals.id = req.body.id;
//     // if (req.body.id) {
//     //     app.locals.id = req.body.id;
//     // }
//     User.findById(app.locals.id)
//         .then(userInDB => {
//             req.user = userInDB;
//             console.log("app.use req.user "+req.user);
//             //console.log(req.user);
//             next();
//         })
//         .catch(err => console.log(err));
// });


app.use('/shop', (req, res, next) => {
    //console.log("/shop req.body.id "+req.body.id)
    app.locals.id = req.body.id;
    // if (req.body.id) {
    //     app.locals.id = req.body.id;
    // }
    User.findById(app.locals.id)
        .then(userInDB => {
            req.user = userInDB;
            //console.log("app.use shop req.user "+req.user);
            //console.log("app.use shop applocalsid "+app.locals.id);
            next();
        })
        .catch(err => console.log(err));
    res.status(200);
});
app.use('/add-to-cart', (req, res, next) => {
    //console.log("/add-to-cart req.body.id "+req.body.id)
    // app.locals.id = req.body.id;
    // if (req.body.id) {
    //     app.locals.id = req.body.id;
    // }
    User.findById(app.locals.id)
        .then(userInDB => {
            req.user = userInDB;
            //console.log("app.use add-to-cart req.user "+req.user);
            //console.log("app.use add-to-cart applocalsid "+app.locals.id);
            next();
        })
        .catch(err => console.log(err));
});
app.use('/cart', (req, res, next) => {
    //console.log("/cart req.body.id "+req.body.id)
    //console.log("/cart app.locals.id "+app.locals.id)
    if (req.body.id) {
        app.locals.id = req.body.id;
    }
    User.findById(app.locals.id)
        .then(userInDB => {
            req.user = userInDB;
            //console.log("app.use cart req.user "+req.user);
            //console.log("app.use cart applocalsid "+app.locals.id);
            next();
        })
        .catch(err => console.log(err));
});
app.use('/delete-cart', (req, res, next) => {
    //console.log("/delete-cart req.body.id "+req.body.id)
    //console.log("/cart app.locals.id "+app.locals.id)
    if (req.body.id) {
        app.locals.id = req.body.id;
    }
    User.findById(app.locals.id)
        .then(userInDB => {
            req.user = userInDB;
            //console.log("app.use delete-cart req.user "+req.user);
            //console.log("app.use delete-cart applocalsid "+app.locals.id);
            next();
        })
        .catch(err => console.log(err));
});
app.use('/shop', adminMainRoutes);
app.use(shopRoutes);
//app.use(userRoutes);
app.use('/logout', (req, res, next) => {
    console.log(req.body.commanD);
    if (req.body.commanD == "logoutOK") {
        console.log("logged out!");
        app.locals.id = undefined;
        res.status(200).end();
    } else {
        res.status(404).end();
    }

})

//Process specific functions
app.post('/check_user', users);
app.post('/reg_user', users);

app.use((req, res, next) => {
    res.status(404).send('Page Not Found');
});

//Server
app.listen(PORT, ()=> { console.log(`Server is running on http://localhost:${PORT}`)});